#include "CreateTree.h"

int main() {
	TestCreateTree();
}